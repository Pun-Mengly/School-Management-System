﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SchoolManagementSystem.Models
{
    public partial class Attendance
    {
        public int AttId { get; set; }
        public int StuId { get; set; }
        public DateTime AttDate { get; set; }
        public bool AttStatus { get; set; }
        public string AttRemark { get; set; }

        public virtual Student Stu { get; set; }
    }
}
