﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SchoolManagementSystem.Models
{
    public partial class Student
    {
        public Student()
        {
            Attendances = new HashSet<Attendance>();
            Enrollments = new HashSet<Enrollment>();
            Grades = new HashSet<Grade>();
        }

        public int StuId { get; set; }
        public int ParentId { get; set; }
        public string StuName { get; set; }
        public string StuGender { get; set; }
        public DateTime StuBd { get; set; }
        public string StuPhone { get; set; }
        public string StuAddress { get; set; }
        public string StuClass { get; set; }
        public int StuYear { get; set; }
        public bool? StuStatus { get; set; }

        public virtual Parent Parent { get; set; }
        public virtual ICollection<Attendance> Attendances { get; set; }
        public virtual ICollection<Enrollment> Enrollments { get; set; }
        public virtual ICollection<Grade> Grades { get; set; }
    }
}
