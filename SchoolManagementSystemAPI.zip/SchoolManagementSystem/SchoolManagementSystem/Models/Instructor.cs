﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SchoolManagementSystem.Models
{
    public partial class Instructor
    {
        public int InstrucId { get; set; }
        public int TeachId { get; set; }
        public int SubId { get; set; }

        public virtual Subject Sub { get; set; }
        public virtual Teacher Teach { get; set; }
    }
}
