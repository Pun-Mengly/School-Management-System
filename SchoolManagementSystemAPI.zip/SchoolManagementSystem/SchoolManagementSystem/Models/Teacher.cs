﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SchoolManagementSystem.Models
{
    public partial class Teacher
    {
        public Teacher()
        {
            Instructors = new HashSet<Instructor>();
        }

        public int TeachId { get; set; }
        public string TeachName { get; set; }
        public string TeachGender { get; set; }
        public DateTime TeachBd { get; set; }
        public string TeachPhone { get; set; }
        public string TeachAddress { get; set; }
        public bool TeachStatus { get; set; }

        public virtual ICollection<Instructor> Instructors { get; set; }
    }
}
