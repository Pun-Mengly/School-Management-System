﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SchoolManagementSystem.Models
{
    public partial class Subject
    {
        public Subject()
        {
            Grades = new HashSet<Grade>();
            Instructors = new HashSet<Instructor>();
        }

        public int SubId { get; set; }
        public string SubName { get; set; }
        public byte SubCredit { get; set; }
        public DateTime SubStartdate { get; set; }
        public DateTime SubEnddate { get; set; }
        public int CourseId { get; set; }

        public virtual Course Course { get; set; }
        public virtual ICollection<Grade> Grades { get; set; }
        public virtual ICollection<Instructor> Instructors { get; set; }
    }
}
