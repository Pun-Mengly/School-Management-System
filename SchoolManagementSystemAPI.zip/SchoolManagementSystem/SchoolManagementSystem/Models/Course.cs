﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SchoolManagementSystem.Models
{
    public partial class Course
    {
        public Course()
        {
            Enrollments = new HashSet<Enrollment>();
            Subjects = new HashSet<Subject>();
        }

        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public byte CourseDur { get; set; }
        public string CourseDes { get; set; }

        public virtual ICollection<Enrollment> Enrollments { get; set; }
        public virtual ICollection<Subject> Subjects { get; set; }
    }
}
