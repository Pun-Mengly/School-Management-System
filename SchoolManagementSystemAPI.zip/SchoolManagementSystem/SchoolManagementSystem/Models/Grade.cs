﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SchoolManagementSystem.Models
{
    public partial class Grade
    {
        public int GradeId { get; set; }
        public int StuId { get; set; }
        public byte GradeScore { get; set; }
        public short GradeYear { get; set; }
        public byte GradeSemester { get; set; }
        public int SubId { get; set; }

        public virtual Student Stu { get; set; }
        public virtual Subject Sub { get; set; }
    }
}
