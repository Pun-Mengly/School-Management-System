﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace SchoolManagementSystem.Models
{
    public partial class school_management_systemContext : DbContext
    {
        public school_management_systemContext()
        {
        }

        public school_management_systemContext(DbContextOptions<school_management_systemContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Attendance> Attendances { get; set; }
        public virtual DbSet<Course> Courses { get; set; }
        public virtual DbSet<Enrollment> Enrollments { get; set; }
        public virtual DbSet<Grade> Grades { get; set; }
        public virtual DbSet<Instructor> Instructors { get; set; }
        public virtual DbSet<Parent> Parents { get; set; }
        public virtual DbSet<Student> Students { get; set; }
        public virtual DbSet<Subject> Subjects { get; set; }
        public virtual DbSet<Teacher> Teachers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                
                optionsBuilder.UseSqlServer("Server=.\\;Database=school_management_system;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Attendance>(entity =>
            {
                entity.HasKey(e => e.AttId)
                    .HasName("PK_Attendaces");

                entity.ToTable("attendances");

                entity.HasIndex(e => e.StuId, "IX_Attendaces_StudentId");

                entity.Property(e => e.AttId).HasColumnName("att_id");

                entity.Property(e => e.AttDate)
                    .HasColumnName("att_date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.AttRemark)
                    .HasMaxLength(40)
                    .HasColumnName("att_remark");

                entity.Property(e => e.AttStatus).HasColumnName("att_status");

                entity.Property(e => e.StuId).HasColumnName("stu_id");

                entity.HasOne(d => d.Stu)
                    .WithMany(p => p.Attendances)
                    .HasForeignKey(d => d.StuId)
                    .HasConstraintName("FK_Attendaces_Students_StudentId");
            });

            modelBuilder.Entity<Course>(entity =>
            {
                entity.ToTable("courses");

                entity.Property(e => e.CourseId).HasColumnName("course_id");

                entity.Property(e => e.CourseDes)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("course_des");

                entity.Property(e => e.CourseDur).HasColumnName("course_dur");

                entity.Property(e => e.CourseName)
                    .IsRequired()
                    .HasMaxLength(25)
                    .HasColumnName("course_name");
            });

            modelBuilder.Entity<Enrollment>(entity =>
            {
                entity.HasKey(e => e.EnrollId)
                    .HasName("PK_Enrollments");

                entity.ToTable("enrollments");

                entity.HasIndex(e => new { e.StuId, e.CourseId }, "UnStuIdCourseId")
                    .IsUnique();

                entity.Property(e => e.EnrollId).HasColumnName("enroll_id");

                entity.Property(e => e.CourseId).HasColumnName("course_id");

                entity.Property(e => e.EnrollDate)
                    .HasColumnType("datetime")
                    .HasColumnName("enroll_date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.StuId).HasColumnName("stu_id");

                entity.HasOne(d => d.Course)
                    .WithMany(p => p.Enrollments)
                    .HasForeignKey(d => d.CourseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Enrollments_Courses");

                entity.HasOne(d => d.Stu)
                    .WithMany(p => p.Enrollments)
                    .HasForeignKey(d => d.StuId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Enrollments_Students");
            });

            modelBuilder.Entity<Grade>(entity =>
            {
                entity.ToTable("grades");

                entity.Property(e => e.GradeId).HasColumnName("grade_id");

                entity.Property(e => e.GradeScore).HasColumnName("grade_score");

                entity.Property(e => e.GradeSemester).HasColumnName("grade_semester");

                entity.Property(e => e.GradeYear).HasColumnName("grade_year");

                entity.Property(e => e.StuId).HasColumnName("stu_id");

                entity.Property(e => e.SubId).HasColumnName("sub_id");

                entity.HasOne(d => d.Stu)
                    .WithMany(p => p.Grades)
                    .HasForeignKey(d => d.StuId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Grade_Students");

                entity.HasOne(d => d.Sub)
                    .WithMany(p => p.Grades)
                    .HasForeignKey(d => d.SubId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Grade_Subject");
            });

            modelBuilder.Entity<Instructor>(entity =>
            {
                entity.HasKey(e => e.InstrucId)
                    .HasName("PK_Instuctors");

                entity.ToTable("instructors");

                entity.HasIndex(e => e.SubId, "IX_Instuctors_Sub_id");

                entity.Property(e => e.InstrucId).HasColumnName("instruc_id");

                entity.Property(e => e.SubId).HasColumnName("sub_id");

                entity.Property(e => e.TeachId).HasColumnName("teach_id");

                entity.HasOne(d => d.Sub)
                    .WithMany(p => p.Instructors)
                    .HasForeignKey(d => d.SubId)
                    .HasConstraintName("FK_Instuctors_Subject_Sub_id");

                entity.HasOne(d => d.Teach)
                    .WithMany(p => p.Instructors)
                    .HasForeignKey(d => d.TeachId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Instuctors_Teachers");
            });

            modelBuilder.Entity<Parent>(entity =>
            {
                entity.ToTable("parents");

                entity.Property(e => e.ParentId).HasColumnName("parent_id");

                entity.Property(e => e.FatherName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("father_name");

                entity.Property(e => e.MotherName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("mother_name");

                entity.Property(e => e.ParentAddress)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("parent_address");

                entity.Property(e => e.ParentPhone)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("parent_phone");
            });

            modelBuilder.Entity<Student>(entity =>
            {
                entity.HasKey(e => e.StuId)
                    .HasName("PK_Students");

                entity.ToTable("students");

                entity.HasIndex(e => e.ParentId, "IX_Students_parentId");

                entity.Property(e => e.StuId).HasColumnName("stu_id");

                entity.Property(e => e.ParentId).HasColumnName("parent_id");

                entity.Property(e => e.StuAddress)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("stu_address");

                entity.Property(e => e.StuBd).HasColumnName("stu_bd");

                entity.Property(e => e.StuClass)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("stu_class");

                entity.Property(e => e.StuGender)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("stu_gender");

                entity.Property(e => e.StuName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("stu_name");

                entity.Property(e => e.StuPhone)
                    .HasMaxLength(20)
                    .HasColumnName("stu_phone");

                entity.Property(e => e.StuStatus)
                    .HasColumnName("stu_status")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.StuYear).HasColumnName("stu_year");

                entity.HasOne(d => d.Parent)
                    .WithMany(p => p.Students)
                    .HasForeignKey(d => d.ParentId)
                    .HasConstraintName("FK_Students_Parents_parentId");
            });

            modelBuilder.Entity<Subject>(entity =>
            {
                entity.HasKey(e => e.SubId)
                    .HasName("PK_Subject");

                entity.ToTable("subjects");

                entity.HasIndex(e => new { e.SubName, e.CourseId }, "SubName&CouseId")
                    .IsUnique();

                entity.Property(e => e.SubId).HasColumnName("sub_id");

                entity.Property(e => e.CourseId).HasColumnName("course_id");

                entity.Property(e => e.SubCredit).HasColumnName("sub_credit");

                entity.Property(e => e.SubEnddate)
                    .HasColumnType("date")
                    .HasColumnName("sub_enddate");

                entity.Property(e => e.SubName)
                    .IsRequired()
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("sub_name");

                entity.Property(e => e.SubStartdate)
                    .HasColumnType("date")
                    .HasColumnName("sub_startdate");

                entity.HasOne(d => d.Course)
                    .WithMany(p => p.Subjects)
                    .HasForeignKey(d => d.CourseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Subject_Courses1");
            });

            modelBuilder.Entity<Teacher>(entity =>
            {
                entity.HasKey(e => e.TeachId)
                    .HasName("PK_Teachers_1");

                entity.ToTable("teachers");

                entity.Property(e => e.TeachId).HasColumnName("teach_id");

                entity.Property(e => e.TeachAddress)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("teach_address");

                entity.Property(e => e.TeachBd).HasColumnName("teach_bd");

                entity.Property(e => e.TeachGender)
                    .IsRequired()
                    .HasMaxLength(5)
                    .HasColumnName("teach_gender");

                entity.Property(e => e.TeachName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("teach_name");

                entity.Property(e => e.TeachPhone)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("teach_phone");

                entity.Property(e => e.TeachStatus).HasColumnName("teach_status");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
