﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SchoolManagementSystem.Models
{
    public partial class Enrollment
    {
        public int EnrollId { get; set; }
        public DateTime EnrollDate { get; set; }
        public int StuId { get; set; }
        public int CourseId { get; set; }

        public virtual Course Course { get; set; }
        public virtual Student Stu { get; set; }
    }
}
