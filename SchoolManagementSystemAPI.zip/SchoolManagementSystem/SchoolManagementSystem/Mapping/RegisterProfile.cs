﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using SchoolManagementSystem.Dtos;
using SchoolManagementSystem.Models;

namespace SchoolManagementSystem.Mapping
{
    public class RegisterProfile:Profile
    {
        public RegisterProfile()
        {
            CreateMap<ParentDto, Parent>()
                .ForMember(e => e.FatherName, e => e.MapFrom(e => e.FatherName))
                .ForMember(e => e.MotherName, e => e.MapFrom(e => e.MotherName))
                .ForMember(e => e.ParentPhone, e => e.MapFrom(e => e.ParentPhone))
                .ForMember(e => e.ParentAddress, e => e.MapFrom(e => e.ParentAddress))
                .ForMember(e => e.Students, e => e.MapFrom(e => e.StudentDtos.Select(s => new Student()
                {
                    StuName = s.StudentName,
                    StuGender = s.StudentGender,
                    StuBd = s.StudentBd,
                    StuPhone = s.StudentPhone,
                    StuAddress = s.StudentAdd,
                    StuClass = s.StudentClass
                }))
                
                );
        }
    }
}
