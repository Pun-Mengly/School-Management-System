﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagementSystem.Dtos
{
    public class ParentDto
    {
        public string FatherName { get; set; }
        public string MotherName { get; set; }
        public string ParentPhone { get; set; }
        public string ParentAddress { get; set; }
        public ICollection<StudentDto> StudentDtos { get; set; }
    }
}
