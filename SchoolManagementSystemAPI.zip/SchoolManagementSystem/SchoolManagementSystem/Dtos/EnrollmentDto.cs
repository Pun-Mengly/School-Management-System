﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagementSystem.Dtos
{
    public class EnrollmentDto
    {
        public DateTime EnrollDate { get; set; }
    }
}
