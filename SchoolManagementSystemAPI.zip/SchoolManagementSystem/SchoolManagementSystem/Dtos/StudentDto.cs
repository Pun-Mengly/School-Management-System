﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolManagementSystem.Dtos
{
    public class StudentDto
    {
        public string StudentName { get; set; }
        public string StudentGender { get; set; }
        public DateTime StudentBd { get; set; }
        public string StudentPhone { get; set; }
        public string StudentAdd { get; set; }
        public string StudentClass { get; set; }
    }
}
